rm -rf ../storage/logs/*
touch ../storage/logs/laravel.log
tail -f -n 450 ../storage/logs/laravel.log \
  | grep -i -E \
    "^\[\d{4}\-\d{2}\-\d{2} \d{2}:\d{2}:\d{2}\]|Next [\w\W]+?\:" \
    --color