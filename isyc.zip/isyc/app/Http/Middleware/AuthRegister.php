<?php

namespace App\Http\Middleware;

use App\Models\Users\AdminEntity;
use App\Models\Users\RadiologistEntity;
use App\Models\Users\StaffEntity;
use App\Models\Users\UserEntity;
use Closure;

class AuthRegister
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle( $request, Closure $next)
    {

        if( ! $user = \Auth::user() ) {
            return redirect( 'login' )->with(
                [ 'message'=> 'You need to login to access registration section', 'alert'=>'danger']
            );
        }

        if( $user->user_type != 'register' ) {
            return redirect( 'login' )->with('message', 'Permission denied' );
        }

        return $next($request);

    }
}
