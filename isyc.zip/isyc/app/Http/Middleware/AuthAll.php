<?php

namespace App\Http\Middleware;

use App\Models\Users\AdminEntity;
use App\Models\Users\RadiologistEntity;
use App\Models\Users\RegistrarEntity;
use App\Models\Users\StaffEntity;
use App\Models\Users\TeacherEntity;
use App\Models\Users\UserEntity;
use Closure;

class AuthAll
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if( ! $user = \Auth::user() ) {

            if ($request->ajax() || $request->wantsJson()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect()->guest('login');
            }
        }

        if( ! UserEntity::me() ){

            /**
             * TODO improve this code
             */
            switch( \Auth::user()->user_type ){
                case 'admin':
                    $user = ( new AdminEntity )->find( \Auth::user()->id );
                break;
                case 'registrar':
                    $user = ( new RegistrarEntity )->find( \Auth::user()->id );
                break;
                default:
                case 'teacher':
                    $user = ( new TeacherEntity )->find( \Auth::user()->id );
                break;
            }

            UserEntity::setupMe( $user ) ;

        }

        return $next($request);

    }
}
