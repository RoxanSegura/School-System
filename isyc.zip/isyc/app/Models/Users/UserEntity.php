<?php

namespace App\Models\Users;

use App\Events\NewUserEvent;
use App\Models\BaseModel;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;

class UserEntity extends BaseModel{

    use Notifiable;

    protected $table      = 'users';
    protected $primaryKey = 'id';

    protected $appends = [ 'full_name' , 'thumb_profile_photo'];
    private static $instances = [];
    private $raw_pass;

    protected $hidden = [
        'password', 'remember_token', 'updated_at','created_at'
    ];

    protected $fillable = [ 'id', 'username', 'email', 'password','user_type','first_name',
        'last_name','title','name_extension', 'gender',
        'mobile', 'landline'
    ];

    public $user_types = [ 'admin'  ];


    /**
     * Get the raw password created when adding new users
     * @return string
     */
    public function getRawPass(){
        return $this->raw_pass;
    }
    /**
     * Create an instance of the current user
     * @param $current
     * @return mixed
     *
     */
    public static function setupMe( $user )
    {
        static::$instances[ 'me' ] = $user;
        return $user;
    }

    /**
     * @return UserEntity
     */
    public static function me()
    {
        return isset( static::$instances[ 'me' ] ) ? static::$instances[ 'me' ] : null;
    }

    /**
     * Checks if user is an Admin
     * @return bool
     */
    public function isAdmin()
    {
        return $this->user_type == 'admin' ? true : false;
    }

    public function displayName(  )
    {
        return $this->first_name.' '.$this->last_name;
    }

    public function getFullNameAttribute()
    {
        return $this->displayName();
    }

    /**
     * @return string
     */
    public function getProfilePhotoUrlAttribute( $value )
    {
        if( ! $value ){
            return url( 'images/ph.jpg' );
        }

        return $value;
    }

    public function getThumbProfilePhotoAttribute()
    {
        $basename = basename( $this->profile_photo_url ) ;

        if( ! $this->profile_photo_url || $basename == 'ph.jpg' ){
            return url( 'images/ph.jpg' );
        }

        return str_replace( $basename , 'thumb_'.$basename , $this->profile_photo_url );
    }


    /**
     * Get the profile photo url
     *
     * @param bool $thumb
     * @return string url
     */
    public function getProfilePhotoUrl( $thumb = true )
    {
        if( ! $this->profile_photo_url ){
            return url( 'images/ph.jpg' );
        }

        if( ! $thumb ){
            return $this->profile_photo_url;
        }

        $basename = basename( $this->profile_photo_url ) ;

        return str_replace( $basename , 'thumb_'.$basename , $this->profile_photo_url );

    }


}