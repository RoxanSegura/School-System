<?php


namespace App\Models\Users;

use App\Models\BaseModel;
use App\Models\Documents\Documents;
use App\Models\School\SchoolYear;
use App\Models\School\StudentSchoolYear;
use App\Models\Settings\Settings;
use Helpers\ImageHelper;
use Illuminate\Http\Request;


class Registrations extends BaseModel
{
    protected $table = 'registrations';
    protected $primaryKey = 'registration_id';
    protected $fillable =[ 'registration_id', 'sid', 'level_id','student_id', 'first_name' , 'last_name' , 'middle_name', 'birthday', 'gender', 'mobile',
        'street_address','barangay','city','landline','religion',
        'father_first_name','father_last_name','father_middle_name','father_mobile','father_landline','father_occupation','father_office_address',
        'mother_first_name','mother_last_name','mother_middle_name','mother_mobile','mother_landline','mother_occupation','mother_office_address',
        'emergency_contact_first_name','emergency_contact_last_name','emergency_contact_middle_name','emergency_contact_numbers',
        'relation_to_child','emergency_contact_address', 'photo_url'
    ];

    protected $appends = [ 'full_name' , 'thumb' ];

    public function store( $data = [] )
    {
        $validator = \Validator::make( $data , [
            'first_name' => 'required',
            'last_name' => 'required',
            'middle_name' => 'required',
            'street_address' => 'required',
            'barangay' => 'required',
            'city' => 'required',
            'landline' => 'required',
            'religion' => 'required',
            'father_first_name' => 'required',
            'father_last_name' => 'required',
            'mother_first_name' => 'required',
            'mother_last_name' => 'required',
            'emergency_contact_first_name' => 'required',
            'emergency_contact_last_name' => 'required',
            'relation_to_child' => 'required',
            'emergency_contact_numbers' => 'required',
            'emergency_contact_address' => 'required',
            'photo_url' => 'image|nullable|max:5000',
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $data );
        $pk = $this->primaryKey;

        if( isset( $data[$pk] ) && $data[$pk]  ){
            $this->exists = true;
        }else{
            $this->status   = 'pending';
            $this->sid      = $this->sid ? $this->sid : $this->generateSid();
        }

        $this->save();

        return $this;
    }

    /**
     * @param Request $r
     * @return StudentSchoolYear
     * @throws \Exception
     */
    public function saveSchoolYearMap( Request $r )
    {
        $sy_map = new StudentSchoolYear;

        $school_year_id = ( new Settings )->getValueByKey( 'current_school_year' );

        $r->merge([ 'sid'  => $this->sid,
            'school_year_id'  => $school_year_id,
            'grade_level_id' => $r->level_id
        ]);

        if( ! $sy_map->store( $r ) ){
            throw new \Exception;
        }

        return $sy_map;
    }

    public function getCollection( Request $r )
    {
        $this->setLpo( $r );
        $this->fields = [ 'a.*' , 'grade_level' ];

        $this->query = static::from( $this->table.' as a' )
         ->join( 'grade_levels as l' , 'l.level_id','=', 'a.level_id' );
        // apply filters here

        $this->query->with( [ 'documents' ]);

        if( $r->q ){
            $this->query->whereRaw( "match(first_name,last_name) against (? in boolean mode)", [$r->q]);
            $this->fields[] = \DB::raw( " MATCH ( first_name, last_name ) AGAINST ('".$r->q."') AS score" );

            $this->order_by         = 'score';
            $this->order_direction = 'DESC';

        }

        if( $r->return_total ){
           $this->total = $this->query->count( );
        }

        if( $r->sid ){
            $this->query->where( 'sid' , $r->sid );
        }

        $this->assignLpo();

        if( $r->return_builder ){
            return $this->query;
        }

        return $this->query->get( $this->fields );
    }

    public function getFullNameAttribute( )
    {
        return $this->last_name.', '.$this->first_name;
    }

    public function getStatusAttribute( $value )
    {
        return ucwords( $value );
    }



    public function uploadPhoto( Request $r )
    {
        if( ! $this->registration_id ){
            $this->errors[] = 'Invalid registrant';
            return false;
        }

        if( ! $r->file( $r->file_name ) ){
            $this->errors[] = 'Photo not found';
            return false;
        }

        $valid_files = [ 'png', 'jpeg',  'jpg'  ];
        $ext = $r->file( $r->file_name )->getClientOriginalExtension();

        if( ! in_array( strtolower( $ext ) , $valid_files  ) ){
            return [
                'success' =>false,
                'message' => 'Invalid file type. Only png and jpg files are allowed'
            ];
        }

        //$orig_filename  = $r->file( $r->file_name )->getClientOriginalName();
        $new_filename   = 'pc_'.str_random( 6 ).'.'.$ext;

        $destination = $this->generatePhotoPath();
        $url = url( $destination.$new_filename );

        $destination  = public_path().''.$destination;

        if( ! is_dir( $destination )){
            mkdir( $destination , 755 , true );
        }

        $r->file( $r->file_name )->move( $destination, $new_filename );
        $file_path  = $destination.$new_filename;

        $this->photo_url = $url;
        $this->save();

        ImageHelper::generateThumbNails( $file_path , [ 'disable_resize' => true ] );

        return $this;

    }

    public function getThumbAttribute()
    {
        if( $this->photo_url ){
            return ImageHelper::getThumbnail( $this->photo_url );
        }

        return '/images/placeholder.jpg';
    }

    public function documents()
    {
        return $this->hasMany( Documents::class , 'sid' , 'sid' )
            ->where( 'entity' , 'required registration documents' );
    }

    private function generatePhotoPath()
    {
        $date = $this->birthday;
        $m =  date( 'm' , strtotime( $date ));
        $y =  date( 'Y' , strtotime( $date ));

        return '/images/users/'.$y.'/'.$m.'/'.$this->sid.'/';
    }

    private function generateSid()
    {
        //$sid = strtoupper( str_random( 8 ) );
        // get the current school year
        $school_year_id = ( new Settings )->getValueByKey( 'current_school_year' );

        // get the max student id for the school_year

        $suffix_number    =  StudentSchoolYear::getMaxSuffix( $school_year_id ) + 1;

        $suffix_number    =  str_pad( $suffix_number, 5, "0", STR_PAD_LEFT);
        $sid = $school_year_id.'-'.$suffix_number;

        return $sid;
    }

    public static function getBySid(){

    }
}