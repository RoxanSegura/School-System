<?php

namespace App\Models\Users;

use App\Events\NewUserEvent;
use App\Models\BaseModel;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;

class RegistrarEntity extends UserEntity
{

}