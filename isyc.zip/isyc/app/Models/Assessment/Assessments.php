<?php

namespace App\Models\Assessments;

use App\Models\BaseModel;
use Illuminate\Http\Request;

class Assessments extends BaseModel{

    protected $table      = 'assessments';
    protected $primaryKey = 'assessment_id';
    public $timestamps = false;
    protected $appends = [];

    private static $instances = [];
    protected $hidden = [];
    protected $fillable = [ 'assessment_id', 'question', 'skill','assessment_type',
        'materials_needed','reminders', 'category_id' ];

    private function rules( Request $r )
    {
        if( $r->assessment_type == 'question' ){
            return [
                'question' =>'required',
                'category_id' => 'numeric'
            ];
        }

        if( $r->assessment_type == 'activity' ){
            return [
                'skill' =>'required',
                'category_id' => 'numeric'
            ];
        }

        return [ 'assessment_type' => 'required' ];
    }

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , $this->rules( $r ));

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{
            $this->sequence = $this->getLastSequence( $r->category_id );
        }

        $this->save();

        return $this;
    }
    
    public function getSkillAttribute( $value )
    {
        return nl2br( $value );
    }

    public function getLastSequence( $category_id )
    {
        $last = static::where( 'category_id' , $category_id  )->count();
        return $last + 1;
    }

    public function category()
    {
        return $this->hasOne( AssessmentCategories::class , 'category_id' , 'category_id');
    }

}