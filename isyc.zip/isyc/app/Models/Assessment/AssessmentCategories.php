<?php

namespace App\Models\Assessments;

use App\Models\BaseModel;
use Illuminate\Http\Request;

class AssessmentCategories extends BaseModel{

    protected $table      = 'assessment_categories';
    protected $primaryKey = 'category_id';
    public $timestamps = false;
    protected $appends = [];

    private static $instances = [];
    protected $hidden = [];
    protected $fillable = [ 'category_id', 'category', 'parent_id', 'level_id' ];

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{

        }

        $this->save();

        return $this;
    }

    public function getCollection( Request $r )
    {
        $this->setLpo( $r );
        $this->fields = [ 'a.*' ];

        $this->query = static::from( $this->table.' as a' );
        // apply filters here
        if( $r->level_id ){
            $this->query->where('level_id' , $r->level_id );
        }

        if( $r->parent_only ){
            $this->query->where('parent_id', 0 );
        }

        if( $r->return_total ){
           $this->total = $this->query->count( );
        }

        if( $r->with_assessments ){
            $this->query->with( [ 'assessments' ]);
        }

        $this->query->with( [ 'children' ]);
        /**
        if( $r->with_children ){

        }
        **/
        $this->assignLpo();

        if( $r->return_builder ){
            return $this->query;
        }

        return $this->query->get( $this->fields );
    }

    public function assessments()
    {
        $registrant_id = request( 'registration_id');
        if( $registrant_id  ){
            return $this->hasMany( Assessments::class , 'category_id' ,'category_id' )
                ->leftJoin( 'assessment_registrant' , 'assessment_registrant.assessment_id' , '=', 'assessments.assessment_id' )
                ->where( 'assessment_registrant.registration_id' , $registrant_id );
        }else{
            return $this->hasMany( Assessments::class , 'category_id' ,'category_id' );
        }

    }

    public function children(){
        return $this->hasMany( AssessmentCategories::class , 'parent_id', 'category_id' )->with( ['assessments' , 'children' ]);
    }

}