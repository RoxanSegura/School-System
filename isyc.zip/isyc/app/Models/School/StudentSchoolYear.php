<?php

namespace App\Models\School;

use App\Models\BaseModel;
use Helpers\ImageHelper;
use Illuminate\Http\Request;

class StudentSchoolYear extends BaseModel{

    protected $table        = 'student_school_year';
    protected $primaryKey   = 'map_id';
    public $timestamps      = false;
    protected $hidden       = [];
    protected $fillable     = [ 'sid' , 'school_year_id',  'section_id', 'grade_level_id' , 'suffix_number'  ];

    protected $appends = [ 'address', 'full_name' , 'thumb' ];

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{
            $sid_arr = explode('-' , $this->sid );
            $this->suffix_number = (int) $sid_arr[1];
        }

        $this->save();

        return $this;
    }

    public function getCollection( Request $r )
    {
        $this->setLpo( $r );
        $this->fields = [ 'a.*' , 'r.*' , 'grade_level' ];

        $this->query = static::from( $this->table.' as a' )
            ->join( 'registrations as r', 'a.sid' , '=', 'r.sid' )
            ->join( 'grade_levels as l' , 'l.level_id','=', 'r.level_id' );

        // apply filters here
        if( $r->status ){
            if( is_array( $r->status ) ){
                $this->query->whereIn( 'r.status' , $r->status );
            }else{
                $this->query->where( 'r.status' , $r->status );
            }
        }

        if( $r->q ){
            $this->query->whereRaw( "match(first_name,last_name) against (? in boolean mode)", [$r->q]);
            $this->fields[] = \DB::raw( " MATCH ( first_name, last_name ) AGAINST ('".$r->q."') AS score" );

            $this->query->orWhere( 'a.sid' , $r->q );

            $this->order_by         = 'score';
            $this->order_direction = 'DESC';

        }

        if( $r->return_total ){
           $this->total = $this->query->count( );
        }

        $this->assignLpo();

        if( $r->return_builder ){
            return $this->query;
        }

        return $this->query->get( $this->fields );
    }

    public static function getMaxSuffix( $school_year_id )
    {
        $map = static::where( 'school_year_id' , $school_year_id )
            ->orderBy( 'suffix_number' , 'DESC' )->first();

        if( ! $map ){
            return 0;
        }

        return $map->suffix_number;
    }

    public function getFullNameAttribute( )
    {
        return $this->last_name.', '.$this->first_name;
    }

    public function getStatusAttribute( $value )
    {
        return ucwords( $value );
    }

    public function getAddressAttribute()
    {
        return $this->street_address.' '.$this->barangay.', '.$this->city;
    }

    public function uploadPhoto( Request $r )
    {
        if( ! $this->registration_id ){
            $this->errors[] = 'Invalid registrant';
            return false;
        }

        if( ! $r->file( $r->file_name ) ){
            $this->errors[] = 'Photo not found';
            return false;
        }

        $valid_files = [ 'png', 'jpeg',  'jpg'  ];
        $ext = $r->file( $r->file_name )->getClientOriginalExtension();

        if( ! in_array( strtolower( $ext ) , $valid_files  ) ){
            return [
                'success' =>false,
                'message' => 'Invalid file type. Only png and jpg files are allowed'
            ];
        }

        //$orig_filename  = $r->file( $r->file_name )->getClientOriginalName();
        $new_filename   = 'pc_'.str_random( 6 ).'.'.$ext;

        $destination = $this->generatePhotoPath();
        $url = url( $destination.$new_filename );

        $destination  = public_path().''.$destination;

        if( ! is_dir( $destination )){
            mkdir( $destination , 755 , true );
        }

        $r->file( $r->file_name )->move( $destination, $new_filename );
        $file_path  = $destination.$new_filename;

        $this->photo_url = $url;
        $this->save();

        ImageHelper::generateThumbNails( $file_path , [ 'disable_resize' => true ] );

        return $this;

    }

    public function getThumbAttribute()
    {
        if( $this->photo_url ){
            return ImageHelper::getThumbnail( $this->photo_url );
        }

        return '/images/placeholder.jpg';
    }

}

