<?php

namespace App\Models\School;

use App\Models\BaseModel;
use App\Models\Settings\Settings;
use Illuminate\Http\Request;

class SchoolYear extends BaseModel{

    protected $table        = 'school_year';
    protected $primaryKey   = 'scholl_year_id';
    public $timestamps      = false;
    protected $appends      = [];
    protected $hidden       = [];
    protected $fillable     = [ 'school_year_start','school_year_end' , 'description' ];

    public static function current()
    {
        return (new Settings )->getValueByKey( 'current_school_year');
    }
}

