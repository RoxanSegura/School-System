<?php

namespace App\Models\School;

use App\Events\NewUserEvent;
use App\Models\Assessments\AssessmentCategories;
use App\Models\BaseModel;
use App\Models\Documents\DocumentsGradeLevel;
use App\Models\Documents\DocumentsRequired;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;

class GradeLevels extends BaseModel{

    protected $table      = 'grade_levels';
    protected $primaryKey = 'level_id';

    protected $appends = [];
    private static $instances = [];

    protected $hidden = [];

    protected $fillable = [ 'level_id' , 'grade_level', 'grade_level_group'  ];


    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{

        }

        $this->save();

        return $this;
    }

    public function getCollection( Request $r )
    {
        $this->setLpo( $r );
        $this->fields = [ 'a.*' ];

        $this->query = static::from( $this->table.' as a' );
        // apply filters here

        if( $r->with_assessment_categories ){
            $this->query->with( ['assessmentCategories.assessments'] );
        }

        if( $r->with && is_array( $r->with ) ){
            $this->query->with( $r->with  );
        }

        if( $r->return_total ){
           $this->total = $this->query->count( );
        }

        $this->assignLpo();

        if( $r->return_builder ){
            return $this->query;
        }

        return $this->query->get( $this->fields );
    }

    public function assessmentCategories()
    {
        return $this->hasMany( AssessmentCategories::class , 'level_id', 'level_id' )
            ->where( 'parent_id' , 0 )
            ->with(['children']);
    }

    public function requiredDocuments()
    {
        return $this->hasMany( DocumentsGradeLevel::class, 'level_id' , 'level_id' )
            ->join( 'documents_required as dr' , 'dr.dr_id' , '=' ,'documents_grade_level.dr_id' );
    }
}