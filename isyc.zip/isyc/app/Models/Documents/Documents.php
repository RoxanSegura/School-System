<?php


namespace App\Models\Documents;


use App\Models\BaseModel;
use App\Models\Users\Registrations;
use App\Models\Users\UserEntity;
use Illuminate\Http\Request;

class Documents extends BaseModel{

    protected   $table      = 'documents';
    protected   $primaryKey = 'document_id';
    public      $timestamps = false;
    protected   $appends = [];

    private static $instances = [];
    protected $hidden = [];
    protected $fillable = [ 'sid', 'document_name', 'path' , 'server' ,'entity_id' , 'entity' , 'path' ];

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{
            $this->uploaded_at = date('Y-m-d H:i:s');
            $this->uploaded_by = UserEntity::me()->id;
        }

        $this->save();

        return $this;
    }

    public function upload( Request $r )
    {
        if( ! $r->file( $r->file_name ) ){
            $this->errors[] = 'Photo not found';
            return false;
        }

        $ext = $r->file( $r->file_name )->getClientOriginalExtension();

        $new_filename   = 'doc_'.str_random( 6 ).'.'.$ext;

        if( ! $destination = $this->generateDocumentPath( $r->sid ) ){
            $this->errors[] = 'Cannot generate document path';
            return false;
        }
        $url = url( $destination.$new_filename );

        $destination  = public_path().''.$destination;

        if( ! is_dir( $destination )){
            mkdir( $destination , 755 , true );
        }

        $r->file( $r->file_name )->move( $destination, $new_filename );
        $file_path  = $destination.$new_filename;
        $this->path = $file_path;
        $this->url = $url;

        return $url;

    }

    private function generateDocumentPath( $sid )
    {
        $registrant = Registrations::where('sid',  $sid )->first();
        if( ! $registrant->birthday ){
            $this->errors[] = 'Registrant birthday not found';
            return false;
        }

        $date = $registrant->birthday;
        $m =  date( 'm' , strtotime( $date ));
        $y =  date( 'Y' , strtotime( $date ));

        return '/images/users/'.$y.'/'.$m.'/'.$sid.'/';
    }
}