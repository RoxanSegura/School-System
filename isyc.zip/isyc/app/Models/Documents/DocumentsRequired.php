<?php


namespace App\Models\Documents;


use App\Models\BaseModel;
use App\Models\School\GradeLevels;
use Illuminate\Http\Request;

class DocumentsRequired extends BaseModel{

    protected $table      = 'documents_required';
    protected $primaryKey = 'dr_id';
    public $timestamps = false;
    protected $appends = [];

    private static $instances = [];
    protected $hidden = [];
    protected $fillable = [ 'document_name' , 'dr_id' ];

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{
            // check for duplicate
            if( $this->hasDuplicate( $r->document_name ) ){
                $this->errors[] = 'Duplicate document name';
                return false;
            }
        }

        $this->save();

        return $this;
    }

    public function hasDuplicate( $document_name )
    {
        return static::where('document_name' , $document_name )->count();
    }

    public function getCollection( Request $r )
    {
        $this->setLpo( $r );
        $this->fields = [ 'a.*' ];

        $this->query = static::from( $this->table.' as a' );
        // apply filters here

        if( $r->return_total ){
           $this->total = $this->query->count( );
        }

        $this->assignLpo();

        if( $r->return_builder ){
            return $this->query;
        }

        return $this->query->get( $this->fields );
    }

    public function gradeLevels()
    {
        return $this->hasMany( DocumentsGradeLevel::class , 'dr_id' , 'dr_id' )
            ->join( 'grade_levels' , 'grade_levels.level_id' , '=',  'documents_grade_level.level_id' );
    }
}