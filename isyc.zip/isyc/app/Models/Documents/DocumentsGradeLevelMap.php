<?php


namespace App\Models\Documents;


use App\Models\BaseModel;
use Illuminate\Http\Request;

class DocumentsGradeLevel extends BaseModel{

    protected $table      = 'documents_grade_level';
    protected $primaryKey = 'map_id';
    public $timestamps = false;
    protected $appends = [];

    private static $instances = [];
    protected $hidden = [];
    protected $fillable = [ 'map_id' , 'dr_id' , 'level_id'];

    public function store( Request $r )
    {
        $validator = \Validator::make( $r->all() , [
            // validation rules here
        ] );

        if( $validator->fails() ){
            $this->errors = $validator->errors()->all();
            return false;
        }

        $this->fill( $r->all() );
        $pk = $this->primaryKey;

        if( $r->$pk  ){
            $this->exists = true;
        }else{

        }

        $this->save();

        return $this;
    }
}