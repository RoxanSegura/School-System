<?php

namespace App\Models\Settings;

use App\Models\BaseModel;
use Illuminate\Http\Request;

class Settings extends BaseModel{

    protected $table        = 'settings';
    protected $primaryKey   = 'setting_id';
    public $timestamps      = false;
    protected $appends      = [];
    protected $hidden       = [];
    protected $fillable     = [ 'setting' , 'value' ];

    public function getValueByKey( $key )
    {
        $setting = static::where( 'setting' , $key )->first();

        if( $setting ){
            return $setting->value;
        }

        return null;
    }
}

