<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

if( request()->segment( 1 ) == 'admin'){
    Route::group( [ 'prefix'=>'admin', 'namespace' => 'Admin', 'middleware' => ['auth'] ] , function(){
        require_once( __DIR__.'/web/route_admin.php');
    });

    //Route::get('admin/student/assessment/{registrant}', 'Teacher/TeacherStudentsController@studentAssessment');
    return;
}

if( request()->segment( 1 ) == 'teacher'){
    Route::group( [ 'prefix'=>'teacher', 'namespace' => 'Teacher', 'middleware' => ['auth'] ] , function(){
        require_once( __DIR__.'/web/route_teacher.php');
    });
    return;
}

if( request()->segment( 1 ) == 'ajax' ){
    Route::group( [ 'prefix'=>'ajax', 'namespace' => 'Ajax' ] , function(){
        require_once( __DIR__.'/web/route_ajax.php');
    });
    return;
}

Route::get('/', function(){
    return redirect( 'login' );
});

Route::get('login', 'FrontController@login');
Route::post('login', 'FrontController@login');
Route::get('logout', 'FrontController@logout');
Route::get( 'register', 'FrontController@register')->middleware( [ 'web', 'register' ] );
Route::get( 'register/success', 'FrontController@registerSuccesful')->middleware( [ 'web', 'register' ] );


Route::group( [ 'prefix'=>'download',  'middleware' => ['auth'] ] , function(){
    Route::get( '{document_id}/{sid}', 'DownloadController@download' );

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    // return what you want
});
});