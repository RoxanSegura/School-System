<?php

Route::get('assessment/{assessment}', 'AjaxAssessmentController@getAssessment');

Route::post('register', 'AjaxStudentsController@saveRegistration');
Route::get('registration/init', 'AjaxStudentsController@initRegistration');
Route::get('registration/seed', 'AjaxStudentsController@seedRegistration');
Route::get('registrations/init', 'AjaxStudentsController@initRegistrations');
Route::post('registration/status', 'AjaxStudentsController@updateRegistrationStatus');

Route::get('registrants/search', 'AjaxRegistrationsController@search');

Route::get( 'student/assessment/init', 'AjaxStudentsController@initAssessment');
Route::get( 'student/assessment/summary', 'AjaxAssessmentController@assessmentSummary');
Route::post('student/assessment', 'AjaxAssessmentController@saveAssessment');
Route::post('student/photo', 'AjaxStudentsController@uploadPhoto');

Route::post('document/upload', 'AjaxToolsController@uploadDocument')->middleware(['auth']);
Route::delete('document', 'AjaxDocumentsController@delete')
    ->middleware(['auth']);

Route::get('admin/tools/assessment/init', 'AjaxToolsController@initAssessmentBuilder');
Route::post('admin/assessment/category', 'AjaxToolsController@saveAssessmentCategory');
Route::post('admin/assessment', 'AjaxToolsController@saveAssessment');
Route::delete('assessment', 'AjaxAssessmentController@deleteAssessment');

// update the category of an assessment item
// this is not the same as admin/assessment/category
Route::post( 'admin/assessment/category/update', 'AjaxAssessmentController@updateAssessmentCategory');

Route::get('admin/required_document', 'AjaxDocumentsController@getRequiredDocuments');
Route::get('admin/required_documents/init', 'AjaxDocumentsController@initRequiredDocuments');
Route::post('admin/required_document', 'AjaxDocumentsController@saveRequiredDocument');

Route::get('students', 'AjaxStudentsController@getStudents');
