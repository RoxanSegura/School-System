<?php

Route::get('dashboard', 'TeacherDashboardController@index');
Route::get('registrations', 'TeacherStudentsController@registrations');
Route::get('student/assessment/{registrant}', 'TeacherStudentsController@studentAssessment');




