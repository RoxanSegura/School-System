<?php


if( request()->segment( 2 ) == 'tools'){
    Route::group( [ 'prefix'=>'tools' ] , function(){
        Route::get('assessment/builder', 'AdminToolsController@assessmentBuilder');
        Route::get('documents', 'AdminToolsController@requiredDocuments');
    });
    return;
}

Route::get('dashboard', 'AdminDashboardController@index');
Route::get('students', 'AdminStudentsController@index');
Route::get('teachers', 'AdminTeachersController@index');
Route::get('teachers_register','AdminTeachersController@register');
Route::get('registrations', 'AdminStudentsController@registrations');
Route::get('teachers_register','AdminTeachersController@register');
Route::post('teacher_registers', 'TeacherRegistrationController@teacher_registers'); 


