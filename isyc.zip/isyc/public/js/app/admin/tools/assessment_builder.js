var aVue = new Vue({
    el:'#aDiv',
    data:{
        assessments:[],
        assessment:{ skill:'',materials_needed:'',reminders:'' },
        assessment_type: null,
        grade_levels: [],
        grade_level:{ assessment_categories:[] },
        categories:[],
        category:{ parent_id: 0 },
        saving:false,
        loading:false,
        spinner:'<i class="icon-spinner2 spinner"></i>',
        token: ''
    },
    methods:{
        init(){
            $.get( '/ajax/admin/tools/assessment/init' )
            .done(function( data ){
                if( data.success){
                    this.grade_levels = data.grade_levels;
                    if( this.grade_levels.length && !this.grade_level.level_id ){
                        this.gradeLevelSelected( this.grade_levels[0].level_id );
                    }
                }else{
                    toastr.error( data.message );
                }
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        refreshAssessmentList( level_id ){
            let vm  = this;
            $.get( '/ajax/admin/tools/assessment/init' )
            .done(function( data ){
                if( data.success){
                    vm.grade_levels = data.grade_levels;
                    vm.gradeLevelSelected( level_id );
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        gradeLevelSelected( level_id ){

            this.grade_level = $.grep( this.grade_levels, function( l ){
                return l.level_id == level_id;
            })[0];

            // grade level categories
            this.categories = [];
            let cat;
            let dd;
            let grand_child;

            for( i=0; i < this.grade_level.assessment_categories.length; i++ ){
                d = this.grade_level.assessment_categories[i];
                cat = { category_id : d.category_id, category:d.category , ot: d.category, parent_id:d.parent_id };
                this.categories.push( cat );
                for( j=0; j < d.children.length; j++ ){
                    dd = d.children[ j ];
                    cat = { category_id : dd.category_id, category: dd.category , ot: '&nbsp;&nbsp;&nbsp;&nbsp;- '+dd.category, parent_id:dd.parent_id };
                    this.categories.push( cat );
                    if( dd.children != undefined && dd.children.length ){
                        for( k=0; k < dd.children.length; k++ ){
                            grand_child = dd.children[ k ];
                            cat = { category_id : grand_child.category_id, category: grand_child.category , ot: '&nbsp;&nbsp;&nbsp;&nbsp;- '+grand_child.category, parent_id:grand_child.parent_id };
                            this.categories.push( cat );
                        }
                    }
                }
            }


        },
        /****** categories ********/
        addCategory( parent_id ){
            this.category  = { parent_id: parent_id };
            this.openCategoryModal()
        },
        editCategory( category_id ){
            this.categorySelected( category_id );
            this.openCategoryModal();
        },
        saveCategory(){
            this.saving = true;
            $.post( '/ajax/admin/assessment/category' , $('#categoryForm').serialize() )
            .done(function( data ){
                if( data.success ){
                    //TODO refresh category data
                    /**
                    for( i=0; i < this.grade_levels.length; i++ ){
                        d = this.grade_levels[ i ];
                        if( d.level_id == data.grade_level.level_id ){
                            Vue.set( this.grade_levels , i , data.grade_level );
                            this.gradeLevelSelected( data.grade_level.level_id );
                        }
                    }
                    */
                    toastr.success( 'Category successfully saved' );
                    this.closeCategoryModal();
                    this.init();
                }else{
                    toastr.error( data.message );
                }
                this.saving = false;
            }.bind(this))
            .error(function( data ){
                toastr.error('Something went wrong');
                this.saving = false;
            }.bind(this));
        },
        // change the category of an assessment item
        updateAssessmentCategory()
        {
            let vm = this;
            $.post( '/ajax/admin/assessment/category/update' , $('#scForm').serialize() )
            .done(function( data ){
                if( data.success){
                    toastr.success( 'Assessment Category successfully updated' );
                    $('#selectCategoryModal').modal( 'toggle' );
                    vm.refreshAssessmentList( data.category.level_id );

                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        deleteAssessmentCategory( category_id ){
            this.categorySelected( category_id );
            if( ! confirm('Are you sure you want to delete category '+this.category.category+' ?') ){
                return;
            }
        },
        categorySelected( category_id ){
            this.category = $.grep( this.categories, function( c ){
                return c.category_id == category_id;
            })[0];
            console.log( this.category )
        },
        openCategoryModal(){
            $('#categoryModal').modal()
        },
        closeCategoryModal(){
            $('#categoryModal').modal( 'toggle' );
        },
        /*********** end categories **************/

        addActivity( category_id ){
            this.categorySelected( category_id );
            this.assessment = { category_id : category_id };
            this.openActivityModal();
        },
        deleteActivity(){

        },
        openActivityModal(){
            $('#activityModal').modal()
        },
        closeActivityModal(){
            $('#activityModal').modal( 'toggle' )
        },
        getAssessment( assessment_id ){
            // just get through ajax
            let vm = this;
            this.loading = true;
            $.get( '/ajax/assessment/'+assessment_id )
                .done(function( data ){
                    if( data.success){
                        vm.assessment = data.assessment;
                        vm.assessment_type = data.assessment.assessment_type;
                    }else{
                        toastr.error( data.message );
                    }
                    vm.loading = false;
                })
                .error(function( data ){
                    toastr.error('Something went wrong');
                    vm.loading = false;
                });
        },
        editAssessment( assessment_id ){
            this.getAssessment( assessment_id );
            this.openActivityModal();
        },
        changeAssessmentCategory( assessment_id ){
            this.getAssessment( assessment_id );
            $('#selectCategoryModal').modal()
        },
        deleteAssessment( assessment_id ){
            if( ! confirm('Are you sure you want to delete assessment item? It can no longer be recovered once deleted.')){
                return null;
            }
            let vm = this;
            $.ajax({ url: '/ajax/assessment', type: 'DELETE', dataType:'json',
                data:{ _token : this.token , assessment_id : assessment_id },
                success: function( data ) {
                    toastr.success( 'Assessment successfully deleted' );
                    vm.refreshAssessmentList( data.level_id );
                }
            }).fail(function() {
                toastr.error( 'Something went wrong' );
            })
        },
        saveAssessment(){
            this.saving = true;
            $.post( '/ajax/admin/assessment', $('#assessmentForm').serialize() )
            .done( function( data ){
                if( data.success ){
                    toastr.success( 'Successfully saved!' );
                    this.assessment = {};
                    this.closeActivityModal();
                    this.init();
                }else{
                    toastr.error( data.message );
                }
                this.saving = false;
            }.bind( this ) )
            .error( function( data ){
                toastr.error('Something went wrong');
                this.saving = false;
            }.bind( this ) );
        },
        textarea( text ){
            if( text ){
                return text.replace(/<br\s*[\/]?>/gi, "");
            }
            return '';
        }
    },
    computed:{
        parentCategories(){
            return $.grep( this.categories, function( p ){
                return p.parent_id == 0;
            })
        },
        skill(){
            let str = this.assessment.skill;
            return str.replace(/<br\s*[\/]?>/gi, "");
        }
    },
    mounted:function(){
        this.init();
        this.token = $('input[name=_token]').val();
    }
});
