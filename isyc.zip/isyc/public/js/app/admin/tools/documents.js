var dVue = new Vue({
    el:'#dDiv',
    data:{
        token : '',
        rd: [],
        levels:[],
        progress: 0,
        spinner: '<i class="fa fa-spin fa-refresh,"></i>',
        saving:false
    },
    methods:{
        init(){
            let vm = this;
            $.get('/ajax/admin/required_documents/init')
            .done(function( data ){
                if( data.success){
                    vm.levels = data.grade_levels;
                    vm.rd = data.rd;
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
            //this.getRequiredDocuments();
        },
        getRequiredDocuments(){
            let vm = this;
            $.get('/ajax/admin/required_document')
            .done(function( data ){
                if( data.success){
                    vm.rd = data.rd;
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        addRequiredDocument(){
            $('#editModal').modal();
        },
        saveRequiredDocument(){
            let vm = this;
            vm.saving = true;
            $.post( '/ajax/admin/required_document', $('#dForm').serialize() )
            .done(function( data ){
                if( data.success){
                    $('#editModal').modal( 'toggle' );
                    toastr.success( 'Successfully added a required document' );
                }else{
                    toastr.error( data.message );
                }
                vm.saving = false;
            })
            .error(function( data ){
                toastr.error('Something went wrong');
                vm.saving = false;
            });
        },
        selectAllLevels(){
            if( $('#allcb').is(':checked')){
                $('.cbl').prop( 'checked' ,true );
            }else{
                $('.cbl').prop( 'checked' , false );
            }
        }
    },
    mounted:function(){
        this.init();
        this.token = $('input[name=_token]').val();
    }
});


