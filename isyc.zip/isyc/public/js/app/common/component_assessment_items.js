Vue.component( 'assessment-items', {
    props:["assessments"],
    template: `
        <div>
        <link href="/themes/limit/css/bootstrap.css" rel="stylesheet" type="text/css">
        <table class="table table-striped">
            <tr>
                <th></th>
                <th> Properly Answered / Observation </th>
                <th>Comments</th>
            </tr>
            <tr v-for="a in assessments">
                <td>
                        <div v-show="a.assessment_type == 'question' " v-html="a.question"></div>
                        <div v-show="a.assessment_type == 'activity' " v-html="a.skill"></div>
                </td>
                <td>
                    <div class="form-group" v-show=" a.assessment_type == 'question' ">
                        <select name="" class="form-control" style="width: 80px">
                            <option value=" ">  </option>
                            <option value="Yes"> Yes </option>
                            <option value="No"> No </option>
                        </select>
                    </div>
                    <div class="form-group" v-show="a.assessment_type == 'activity' ">
                        <textarea name="" :name="'observation['+a.assessment_id+']' " id="" class="form-control"></textarea>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <textarea name="" :name="'comment['+a.assessment_id+']' " id="" class="form-control"></textarea>
                    </div>
                </td>
            </tr>
        </table>
        </div>
        `
});