var sVue = new Vue({
    el:'#sDiv',
    data:{
        q: '',
        students:[],
        student:{},
        registrant:{},
        edit_sis:false,
        progress:0,
        gender: '',
        saving: false,
        searching: false
    },
    methods:{
        init(){
            this.getStudents( true );
        },
        saveSis(){

        },
        search(){
           this.getStudents();
        },
        getStudents( is_init ){
            let vm = this;
            vm.searching = true;
            $.get('/ajax/students' , $( '#searchForm' ).serialize() )
            .done(function( data ){
                if( data.success){
                    vm.students = data.students;
                    if( is_init ){
                        if( vm.students[0] != undefined ){
                            vm.student = data.students[0];
                        }
                    }
                }else{
                    toastr.error( data.message );
                }
                vm.searching = false;
            })
            .error(function( data ){
                toastr.error('Something went wrong');
                vm.searching = false;
            });
        },
        studentSelected( sid ){
            this.student = $.grep( this.students , function( s ){
                return s.sid == sid;
            })[0];
        }
    },
    mounted:function(){
        this.init();
    }
});

$('#photo' ).fileupload({
    dataType: 'json',
    progress: function (e, data) {
        var progress = parseInt(data.loaded / data.total * 100, 10);
        $('.bar').css('width', progress + '%');
        sVue.progress = progress;
    },
    done: function (e, data) {
        $('.bar').css('width', '0%');
        sVue.progress = 0;

        if( data.result.success){
            toastr.success( 'Photo successfully uploaded' );
            sVue.progress = 0;
            sVue.student.thumb = data.result.thumb;
        }else{
            toastr.error( data.result.message )
        }
    },
    error: function (e, data) {
        sVue.progress = 0;
        toastr.error( 'Something went wrong')
    }
});