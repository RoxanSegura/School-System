var aVue = new Vue({
    el:'#aDiv',
    data:{
        categories: [],
        category:{ assessments: [] },
        level_id:0,
        saving: false,
        spinner: '<i class="fa fa-spin fa-refresh"></i>',
        check: '<i class="fa fa-check text-green"></i>',
        x:'<i class="fa fa-times text-danger"></i>',
        show_summary: false,
        answers: [],
        answer:{ assessment_id: 0 },
        registration_id : null,
        i: 0
    },
    methods:{
        init(){
            let vm = this;
            this.level_id = $('#level_id').val();
            $.get( '/ajax/student/assessment/init' , {level_id: this.level_id , registration_id:$('#registration_id').val() })
            .done(function( data ){
                if( data.success){
                    vm.categories = data.categories;
                    vm.answers = data.answers;
                    if( vm.categories.length ){
                        vm.category = vm.categories[0];
                    }
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        categorySelected( cid ){
            this.category = $.grep( this.categories , function( c){
                 return c.category_id == cid
            })[0];
            this.show_summary = false;
            //this.category = _.find( this.categories, function( c ) { return c.category_id == cid });
            // get all question for this
        },
        saveAssessment(){
            this.saving = true;
            $.post( '/ajax/student/assessment' , $('#assessmentForm').serialize() )
            .done(function( data ){
                if( data.success){
                    toastr.success( 'Successfully saved' );
                }else{
                    toastr.error( data.message );
                }
                this.saving = false;
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
                this.saving = false;
            }.bind( this ));
        },
        showSummary(){
            this.show_summary = ! this.show_summary;
            this.getSummary();

            /**
            $.get( '/ajax/student/assessment/summary' , {registration_id: this.registration_id} )
            .done(function( data ){
                if( data.success){
                    this.answers = data.answers;
                }else{
                    toastr.error( data.message );
                }
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
            });
             ***/
        },

        getSummary(){
            $.get( '/ajax/admin/tools/assessment/init' )
            .done(function( data ){
                if( data.success){

                }else{
                    toastr.error( data.message );
                }
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },

        getAnswer( assessment_id , field ){
            //this.i++;
            console.log( { i: this.i, a: assessment_id , f:field } );
        }

    },
    computed:{

    },
    mounted:function(){
        // source of truth is the input value
        this.registration_id = $('#registration_id').val();
        this.init();
    }
});