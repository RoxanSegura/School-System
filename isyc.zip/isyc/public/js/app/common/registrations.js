var rVue = new Vue({
    el:'#rDiv',
    data:{
        registrations:[],
        registrant:{ documents: [] },
        categories:[],
        grade_levels:[] ,
        gender:[{value:'M' , text:'Male'},{value:'F' , text:'Female'}],
        answers:[],
        levels:[],
        level:{ required_documents : [] },
        saving:false,
        searching:false,
        spinner: '<i class="fa fa-spin fa-refresh"></i>',
        check: '<i class="fa fa-check text-green"></i>',
        check_large: '<i class="fa fa-check fa-2x text-green"></i>',
        x:'<i class="fa fa-times text-danger"></i>',
        x_large:'<i class="fa fa-times fa-2x text-danger"></i>',
        progress: 0,
        q:'',
        document_upload_ready : false,
        enrollment_status: [ 'Pending', 'Enrolled' , 'Archived', 'Transferred' ],
        edit_sis:false,
        user_type: ''
    },
    methods:{
        init(){
            let vm = this;
            $.get('/ajax/registrations/init' , {sid: $('#request_sid').val() })
            .done(function( data ){
                if( data.success){
                    vm.registrations = data.registrations;
                    vm.levels = data.levels;
                    vm.grade_levels = data.levels;
                    vm.user_type = data.user_type;
                    if( vm.registrations.length ){
                        vm.studentSelected( vm.registrations[0].registration_id );
                        vm.initAssessmentSummary();
                    }
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        requirements(){

        },
        initAssessmentSummary(){
            let vm  = this;
            $.get( '/ajax/student/assessment/init' , { level_id: this.registrant.level_id , registration_id:this.registrant.registration_id })
            .done(function( data ){
                if( data.success){
                    vm.categories = data.categories;
                    vm.answers = data.answers;
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });

        },
        studentSelected( registration_id ){
            let vm = this;
            this.registrant = $.grep( this.registrations , function( r ){
                return r.registration_id == registration_id;
            })[0];
            this.level = $.grep( this.levels , function( l ){
                return l.level_id == vm.registrant.level_id;
            })[0];

            this.initAssessmentSummary();
            this.document_upload_ready = false;
            this.setDocument();

        },
        observation( a ){
            if( a.assessment_type == 'question'){
                if( a.properly_answered == 'Yes' ){
                    return this.check;
                }else if( a.properly_answered == 'No' )
                {
                    return this.x;
                }else{
                    return 'No answer';
                }
            }

            if( a.assessment_type == 'activity'){
                if( a.observation == null ){
                    return 'Not observed';
                }
                return a.observation;
            }

            return 'No data';
        },
        hasRequiredDocument( document_id ){
            let d;
            d = $.grep( this.registrant.documents , function( d ){
                return d.entity == 'required registration documents' && d.entity_id == document_id;
            });
            return d[0] ? d[0] : false;
        },
        setDocument(){
            let vm  = this;
            if( this.document_upload_ready ){
                return;
            }
            $('.document' ).fileupload({
                dataType: 'json',
                progress: function (e, data) {
                    vm.progress  = parseInt(data.loaded / data.total * 100, 10);
                    $('.bar').css('width', vm.progress + '%' );
                },
                done: function (e, data) {
                    $('.bar').css('width', '0%');
                    vm.progress = 0;
                    toastr.success( 'Document successfully uploaded' );
                    vm.registrant = data.result.registrant;
                    for( i=0; i < vm.registrations.length; i++ ){
                        d = vm.registrations[i];
                        if( d.registration_id == data.result.registrant.registration_id ){
                            Vue.set( rVue.registrations , i , data.result.registrant );
                        }
                    }
                    if( data.result.success ){

                    }

                },
                error: function (e, data) {
                    toastr.error( 'Something went wrong' )
                    vm.progress = 0;
                }
            });
        },
        download( dr_id ){
            let doc = this.hasRequiredDocument( dr_id );
            location.href   =   '/download/'+doc.document_id+'/'+doc.sid;
        },
        deleteDocument( dr_id ){
            let doc = this.hasRequiredDocument( dr_id );
            let vm = this;

            if( !confirm( 'Are you sure you want to delete this document?') ){
                return ;
            }

            $.ajax({ url: '/ajax/document', type: 'DELETE',dataType:'json',
                data:{ _token : vm.token, document_id : doc.document_id , sid: doc.sid  },
                success: function( data ) {
                    toastr.success( 'Document successfully deleted' );
                    // delete
                    for( i=0; i < vm.registrant.documents.length; i++ ){
                        d = vm.registrant.documents[i];
                        if( d.document_id == doc.document_id ){
                            vm.registrant.documents.splice( i , 1 );
                            break;
                        }
                    }

                    for( i=0; i < vm.registrants.length; i++ ){
                        d = vm.registrants[i];
                        if( d.sid == doc.sid ){
                            vm.registrants[i].documents = vm.registrant.documents;
                            break;
                        }
                    }
                }
            }).fail(function() {

            })
        },
        setStatus(){
            $('#statusModal').modal()
        },
        saveRegistrationStatus(){
            let vm = this;
            vm.saving = true;
            $.post('/ajax/registration/status' , $('#statusForm').serialize() )
            .done(function( data ){
                if( data.success){
                    toastr.success( 'Registration Status successfully updated' );
                    $('#statusModal').modal( 'toggle' );
                    for( i=0; i < vm.registrations.length; i++ ){
                        d = vm.registrations[i];
                        if( d.registration_id == data.registrant.registration_id ){
                            d.status = data.registrant.status;
                        }
                    }

                }else{
                    toastr.error( data.message );
                }
                vm.saving = false;
            })
            .error(function( data ){
                toastr.error('Something went wrong');
                vm.saving = false;
            });
        },
        toggleSis(){
            this.edit_sis = !this.edit_sis;
        },
        saveSis(){

            this.saving = true;
            $.post('/ajax/register' , $('#registrationForm').serialize() )
                .done(function( data ){
                    if( data.success){
                        toastr.success( 'SIS successfully updated' );
                        this.toggleSis();

                        for( i=0; i < this.registrations.length; i++ ){
                            d   =   this.registrations[i];
                            if( d.registration_id == data.registration.registration_id ){
                                Vue.set( this.registrations , i, data.registration );
                                this.registrant = data.registration;
                            }
                        }

                    }else{
                        toastr.error( data.message );
                    }
                    this.saving = false;
                }.bind( this ))
                .error(function( data ){
                    toastr.error('Something went wrong');
                    this.saving = false;
                }.bind( this ));
        },
        search(){
            let vm = this;
            vm.searching = true;
            if( vm.q.length < 2 ){
                vm.init()
                return;
            }
            $.get('/ajax/registrants/search' , { q:vm.q  } )
            .done(function( data ){
                if( data.success){
                    vm.registrations = data.registrations;
                }else{
                    toastr.error( data.message );
                }
                vm.searching = false;
            })
            .error(function( data ){
                toastr.error('Something went wrong');
                vm.searching = false;
            });
        }
    },
    mounted:function(){
        this.init();
        this.token = $('input[name=_token]').val();
    }
});


$('#photo' ).fileupload({
    dataType: 'json',
    progress: function (e, data) {
        var progress = parseInt(data.loaded / data.total * 100, 10);
        $('.bar').css('width', progress + '%');
        rVue.progress = progress;
    },
    done: function (e, data) {
        $('.bar').css('width', '0%');
        rVue.progress = 0;

        if( data.result.success){
            toastr.success( 'Photo successfully uploaded' );
            rVue.progress = 0;
            rVue.registrant.thumb = data.result.thumb;
        }else{
            toastr.error( data.result.message )
        }
    },
    error: function (e, data) {
        rVue.progress = 0;
        toastr.error( 'Something went wrong')
    }
});