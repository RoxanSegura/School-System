var rVue = new Vue({
    el:'#rDiv',
    data:{
        registrations:[],
        registration:{},
        grade_levels:[],
        saving: false,
        seeding:false,
        spinner: '<i class="fa fa-spin fa-refresh"></i>',
        gender:[{value:'M' , text:'Male'},{value:'F' , text:'Female'}],
        is_current_student : false,
        progress:0,
    },
    methods:{
        init(){
            let vm = this;
            $.get('/ajax/registration/init')
            .done(function( data ){
                if( data.success){
                    vm.grade_levels = data.grade_levels;
                }else{
                    toastr.error( data.message );
                }
            })
            .error(function( data ){
                toastr.error('Something went wrong');
            });
        },
        saveRegistration(){
            this.saving = true;
            // old students should have SID already
            if( this.is_current_student && ! this.registration.sid ){
                toastr.error( 'Current students must have Student Number' );
                this.saving = false;
                return;
            }
            else{
                this.registration.sid = '0000-000';
            }
            
            $.post('/ajax/register' , $('#registrationForm').serialize() )
            .done(function( data ){
                if( data.success){
                    toastr.success( 'Registration successfully saved.' );
                    setTimeout( function(){
                        //location.href='/register/success'
                    }, 1000 )
                }else{
                    toastr.error( data.message );
                }
                this.saving = false;
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
                this.saving = false;
            }.bind( this ));
            
            $.post('/ajax/student/photo' , jQuery('#photo').fileupload())
            .done (function ( data ) {
                if( data.success){
                    toastr.success( 'Photo successfully uploaded' );
                    this.registration.thumb = data.thumb;
                }else{
                    toastr.error( data.result.message )
                }
            }.bind(this))
            .error (function (data) {
                rVue.progress = 0;
                toastr.error( 'Something went wrong')
            }.bind(this));
        },


        seed(){
            this.seeding = true;
            $.get( '/ajax/registration/seed' )
            .done(function( data ){
                if( data.success){
                    this.registration  = data.registration;
                }else{
                    toastr.error( data.message );
                }
                this.seeding = false;
            }.bind( this ))
            .error(function( data ){
                toastr.error('Something went wrong');
                this.seeding = false;
            });
        }

    },
    mounted:function(){
        this.init();
    }
});


$(document).ready(function(){
    $( "#birthday" ).datepicker({ dateFormat: 'yy-mm-dd', changeYear: true, changeMonth: true });
});
