

( function ( $ ){

    var inEditMode = false;

    $.fn.tablr = function( options ) {

        // This is the easiest way to have default options.
        var settings = $.extend({
            // These are the defaults.
            table: 'tablr-list',
            editModal:'editModal',
            obj: {},
            total: 0,
            page_count: [1],
            current_page : 1,
            limit: 20,
            order_by: 'item'
        }, options );

        var current_row     =   {};
        var current_tab     =   {};
        var data_list = $('#'+settings.table );
        var editModal = $('#'+settings.editModal);
        var keyListenersActivated = false;
        var firstRowHighlighted = false;
        var obj = settings.obj;



        if( settings.tablrVue ){
            var tablrVue = settings.tablrVue;
        }

        function highlightFirstRow(){
            current_row = $( data_list.children()[0] );
            current_tab = $( current_row.children()[1] );
            highlightRow();
            activateKeyListeners();
            firstRowHighlighted = true;
        }

        function highlightRow(){
            current_row.children().addClass( 'highlight' );
            current_tab.addClass( 'active' );
        }

        function removeHighlightRow(){
            data_list.children().children().removeClass( 'highlight' );
            data_list.children().children().removeClass( 'active' );
            data_list.children().children().removeClass( 'edit' );
            current_tab.blur();
        }

        function setTableRow( elem ){
            inEditMode = false;
            current_tab = elem;
            current_row = elem.parent();
            highlightRow();
        }

        function activateKeyListeners(){

            if( keyListenersActivated == true ){
                return
            }

            keyListenersActivated = true;

            $( document ).keydown( function(e) {

                var code = e.keyCode || e.which;
                var dl = data_list;

                switch( code ){
                    case 13: // enter

                        if(  current_tab.hasClass( 'modal-edit' ) ){

                            inEditMode = true;
                            editModal.modal();

                            if( f = current_tab.attr( 'data-focus' ) ){
                                $('#'+f).focus()
                            }

                            var data_id = current_tab.attr( 'data-id' );

                            // populate the modal form
                            // source object must implement editTab contract
                            obj.editTab( data_id );

                            return
                        }

                        if( ! e.shiftKey ){

                            e.preventDefault();

                            if( inEditMode ){
                                // user saving data
                                // check if value has changed then save through ajax
                                if( current_tab_value != current_tab.html() ){

                                    obj.saveField( e );
                                }

                                current_tab.attr( 'contenteditable' , false );
                                current_tab.removeClass( 'edit' );
                                current_tab.blur();
                                inEditMode = false;
                            }else{
                                if( current_tab.hasClass( 'editable' ) ) {

                                    current_tab.attr( 'contenteditable' , true );
                                    current_tab.addClass( 'edit' );
                                    current_tab.focus();

                                    current_tab_value = current_tab.html();
                                    inEditMode = true;

                                }else if( current_tab.hasClass( 'tablr-dropdown' ) ){
                                    //current_tab.html()
                                }else{
                                    // do nothing
                                }

                            }
                        }
                        break;
                    case 27: //escape
                        editModal.modal( 'hide' );
                        inEditMode = false;
                        break;
                    case 37: // left
                        new_tab =  current_row.children()[ current_tab.index()-1 ];
                        if( inEditMode || new_tab == undefined ){
                            return;
                        }

                        dl.children().children().removeClass( 'active' );
                        current_tab = $( new_tab );
                        current_tab.addClass( 'active' );
                        break;
                    case 38: // up
                        if( current_row.prev('tr')[0] == undefined || inEditMode ){
                            return
                        }
                        removeHighlightRow();
                        current_row = current_row.prev('tr');
                        current_tab = $(current_row.children()[current_tab.index()]);
                        highlightRow();

                        break;
                    case 39: // right
                        new_tab =  current_row.children()[ current_tab.index() + 1 ];
                        if( inEditMode || new_tab == undefined ){
                            return
                        }

                        current_tab = $( new_tab );
                        dl.children().children().removeClass('active');
                        current_tab.addClass('active');

                        break;
                    case 40: // down
                        if( $.isEmptyObject(current_row) ){
                            return;
                        }
                        if( current_row.next('tr')[0] == undefined || inEditMode ){
                            return
                        }

                        removeHighlightRow();
                        current_row = current_row.next('tr');
                        current_tab = $(current_row.children()[current_tab.index()]);
                        highlightRow();

                        break;
                    case 78: // next
                        if(  e.shiftKey && ! inEditMode ){
                            goToNext()
                        }
                        break;
                    case 80: // previous
                        if(  e.shiftKey && ! inEditMode ){
                            goToPrev()
                        }
                        break;
                    case 65:
                    case 97:
                        if( ! inEditMode ){
                            editModal.modal();
                        }
                        break;
                    case 68:
                        if( ! inEditMode && ! firstRowHighlighted ){
                            highlightFirstRow();
                        }
                        break;
                }

            });
        }

        activateKeyListeners();
        // setup first row
        setTimeout( function(){
            highlightFirstRow();
        }, 1000 );
        return {
            release : function(){
                inEditMode = false;
            },
            lock : function(){
                inEditMode = true;
            },
            tabClick :function( elem ){
                removeHighlightRow();
                setTableRow( elem );
            }
        };
    };


}( jQuery ));