
var tablr = new Vue({
    data:{
        current_row: {},
        current_tab: {},
        keyListenersActivated : false,
        inEditMode: false,
        editModal: 'itemModal'
    },
    methods:{
        highlightFirstRow(){
            var data_list = $('#data-list');
            this.current_row = $( data_list.children()[0] );
            this.current_tab = $( this.current_row.children()[0] );
            this.activateKeyListeners();
            this.highlightRow();
        },
        setTableRow( elem ){
            this.inEditMode = false;
            this.current_tab = elem;
            this.current_row = elem.parent();

            this.activateKeyListeners();
            this.highlightRow();
        },
        trClicked:function( e ){
            var data_list =$('#data-list');

            data_list.children().children().removeClass( 'highlight' );
            data_list.children().children().removeClass( 'active' );

            $( this.current_tab ).removeClass( 'edit' );
            this.setTableRow( $( e.target ) )
        },
        formatUnitPrice( unit_price ){
            return unit_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
        },
        subTotal( i ){
            sub_total = ( i.first_quarter+i.second_quarter+i.third_quarter+i.fourth_quarter ) * i.unit_price;
            return sub_total.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
        },
        highlightRow(){
            this.current_row.children().addClass( 'highlight' );
            this.current_tab.addClass( 'active' );
        },
        removeHighlightRow(){
            var dl = $('#data-list');
            dl.children().children().removeClass( 'highlight' );
            dl.children().children().removeClass( 'active' );
            dl.children().children().removeClass( 'edit' );
            this.current_tab.blur()
        },
        activateKeyListeners(){

            if( this.keyListenersActivated == true ){
                return
            }

            var vm = this;
            vm.keyListenersActivated = true;

            $(document).keypress( function(e) {

                var code = e.keyCode || e.which;
                var dl = $('#data-list');

                switch( code ){
                    case 13: // enter

                        if( $( vm.current_tab ).hasClass( 'modal-edit' ) ){

                            vm.inEditMode = true;
                            
                            $('#'+$( vm.current_tab ).attr( 'data-modal' ) ).modal();
                            if( f = $( vm.current_tab ).attr( 'data-focus' ) ){
                                $('#'+f).focus()
                            }
                            return
                        }

                        if( ! e.shiftKey ){

                            e.preventDefault();

                            if( vm.inEditMode ){
                                // user saving data
                                // check if value has changed then save through ajax
                                if( vm.current_tab_value != $( vm.current_tab ).html() ){
                                    // delay saving so not to save the <br>
                                    tableVue.save( e );
                                }

                                $( vm.current_tab ).attr( 'contenteditable' , false );
                                $( vm.current_tab ).removeClass( 'edit' );
                                $( vm.current_tab ).blur();
                                vm.inEditMode = false;
                            }else{
                                if( $( vm.current_tab ).hasClass( 'editable' ) ) {

                                    $( vm.current_tab ).attr( 'contenteditable' , true );
                                    $( vm.current_tab ).addClass( 'edit' );
                                    $( vm.current_tab ).focus();

                                    vm.current_tab_value = $( vm.current_tab ).html();
                                    vm.inEditMode = true;

                                }else if( $( vm.current_tab ).hasClass( 'tablr-dropdown' ) ){
                                    //$( vm.current_tab ).html()
                                }else{
                                    // do nothing
                                }

                            }
                        }
                        break;
                    case 27:
                        $('#'+vm.editModal).modal( 'hide' );
                        break;
                    case 37: // left
                        new_tab =  vm.current_row.children()[ vm.current_tab.index()-1 ];
                        if( vm.inEditMode || new_tab == undefined ){
                            return;
                        }

                        dl.children().children().removeClass( 'active' );
                        vm.current_tab = $( new_tab );
                        vm.current_tab.addClass( 'active' );
                        break;
                    case 38: // up
                        if( vm.current_row.prev('tr')[0] == undefined || vm.inEditMode ){
                            return
                        }
                        vm.removeHighlightRow();
                        vm.current_row = vm.current_row.prev('tr');
                        vm.current_tab = $(vm.current_row.children()[vm.current_tab.index()]);
                        vm.highlightRow();

                        break;
                    case 39: // right
                        new_tab =  vm.current_row.children()[ vm.current_tab.index() + 1 ];
                        if( vm.inEditMode || new_tab == undefined ){
                            return
                        }

                        vm.current_tab = $( new_tab );
                        dl.children().children().removeClass('active');
                        vm.current_tab.addClass('active');

                        break;
                    case 40: // down
                        if( vm.current_row.next('tr')[0] == undefined || vm.inEditMode ){
                            return
                        }

                        vm.removeHighlightRow();
                        vm.current_row = vm.current_row.next('tr');
                        vm.current_tab = $(vm.current_row.children()[vm.current_tab.index()]);
                        vm.highlightRow();

                        break;
                    case 78: // next
                        if(  e.shiftKey && ! vm.inEditMode ){
                            vm.goToNext()
                        }
                        break;
                    case 80: // previous
                        if(  e.shiftKey && ! vm.inEditMode ){
                            vm.goToPrev()
                        }
                        break;

                }

            });
        }
    }

});

