<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAssessmentRegistrantTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessment_registrant', function (Blueprint $table) {

            $table->increments('map_id');
            $table->integer( 'registration_id' )->index()->unsigned();
            $table->integer( 'assessment_id' )->index()->unsigned();
            $table->string( 'properly_answered' , 20 )->nullable();
            $table->text( 'observation' )->nullable();
            $table->text( 'comment' )->nullable();
            $table->integer( 'added_by' )->unsigned();
            $table->dateTime( 'added_at' );

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessment_registrant');
    }
}
