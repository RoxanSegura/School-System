<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistrationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registrations', function ( Blueprint $table ) {
            $table->increments('registration_id');
            $table->string( 'first_name' ,50 );
            $table->string( 'last_name' ,50);
            $table->string( 'middle_name' ,50);

            $table->string( 'street_address' ,150);
            $table->string( 'barangay' ,150);
            $table->string( 'city' ,50);
            $table->string( 'landline',50)->nullable();
            $table->string( 'religion',50)->nullable();

            $table->string( 'father_first_name' ,50);
            $table->string( 'father_last_name' ,50);
            $table->string( 'father_middle_name' ,50)->nullable();
            $table->string( 'father_mobile' ,50)->nullable();
            $table->string( 'father_landline',50)->nullable();
            $table->string( 'father_occupation',50)->nullable();
            $table->string( 'father_office_address',50)->nullable();

            $table->string( 'mother_first_name',50);
            $table->string( 'mother_last_name',50);
            $table->string( 'mother_middle_name',50)->nullable();
            $table->string( 'mother_mobile',50)->nullable();
            $table->string( 'mother_landline',50)->nullable();
            $table->string( 'mother_occupation',50)->nullable();
            $table->string( 'mother_office_address',50)->nullable();

            $table->string( 'emergency_contact_first_name' ,50);
            $table->string( 'emergency_contact_last_name' ,50);
            $table->string( 'emergency_contact_middle_name' ,50)->nullable();
            $table->string( 'relation_to_child' ,50);
            $table->string( 'emergency_contact_address' ,50);
            $table->string( 'emergency_contact_numbers' ,50);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registrations');
    }
}
