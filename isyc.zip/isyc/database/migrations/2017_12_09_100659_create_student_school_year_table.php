<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentSchoolYearTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student_school_year', function (Blueprint $table) {
            $table->increments('map_id');
            $table->string( 'sid', 40 )->index();
            $table->integer( 'school_year_id' )->unsigned()->index();
            $table->integer( 'section_id' )->unsigned()->nullable();
            $table->integer( 'grade_level_id' )->unsigned()->nullable();
            $table->integer( 'suffix_number' )->unsigned()->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('student_school_year');
    }
}
