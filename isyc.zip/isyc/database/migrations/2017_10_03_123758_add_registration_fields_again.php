<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddRegistrationFieldsAgain extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('registrations', function (Blueprint $table) {

            $table->string( 'sid', 8 )->after( 'registration_id' )->index();
            $table->string( 'photo_url', 150 )->after( 'religion')->nullable();
            $table->string( 'gender' , 1 )->after( 'religion');
            $table->date( 'birthday' )->after( 'religion')->nullable();
            $table->string( 'father_email', 50 )->after( 'father_landline')->nullable();
            $table->string( 'mother_email', 50 )->after( 'mother_landline')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       //
    }
}
